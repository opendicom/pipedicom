# DsourceJ

DICOM binary to DCKV JSON

## arg
DICOM filePath

## stderr
errors

## stdout
json
