# DinlineJ

DICOM binary to DCKV JSON

## stdin
DICOM filePath

## stderr
errors

## stdout
json independiente con blobs inline en base64
