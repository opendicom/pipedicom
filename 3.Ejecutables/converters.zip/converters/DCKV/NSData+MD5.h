//
//  NSData+MD5.h
//  DCKV
//
//  Created by jacquesfauquex on 2021-06-03.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData (MD5)

- (NSString *)MD5String;

@end

NS_ASSUME_NONNULL_END
